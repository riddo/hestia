<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Configuración General</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>">Inicio</a></li>
                    <li class="breadcrumb-item active">Configuración</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<div class="content">
    <div class="row">

            <div class="col-12">
                <div class="card p-4">
                    <form  method="POST" action="<?php echo e(url('admin/config/update')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="id" value="<?php echo e($admin->id); ?>">
                        <div class="form-group">
                            <label for="username">Nombre de usuario</label>
                            <input type="text" class="form-control" name="username" value="<?php echo e($admin->username); ?>">
                        </div>
                        <div class="form-group">
                            <label for="fullname">Nombre Completo</label>
                            <input type="text" class="form-control" name="fullname" value="<?php echo e($admin->nombreCompleto); ?>">
                        </div>
                        <div class="form-group">
                            <label for="empresa">Nombre de la empresa</label>
                            <input type="text" class="form-control" name="empresa" value="<?php echo e($admin->empresa); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e($admin->correo); ?>">
                        </div>

                        <?php if(Session::has('msg')): ?>
                        <p class="text-success">
                            <strong><?php echo e(session('msg')); ?></strong>
                        </p>
                         <?php endif; ?>

                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </div>
                    </form>
                </div>


            </div>



    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Proyectos\hestia\resources\views/admin/config.blade.php ENDPATH**/ ?>