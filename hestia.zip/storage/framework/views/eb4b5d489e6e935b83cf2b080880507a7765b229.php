<h1>Hola</h1>
<?php $__currentLoopData = $registro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\MAMP\htdocs\Proyectos\hestia\resources\views/admin/registros/registro.blade.php ENDPATH**/ ?>