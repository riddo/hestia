<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Inicio</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-primary">
                    <div class="inner">
                        <h3><?php echo e($cantidadEmpleados); ?></h3>

                        <p>Total de empleados</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <a href="<?php echo e(url('admin/empleados')); ?>" class="small-box-footer">Más información <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo e($activos); ?></h3>

                        <p>Empleados activos ahora</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <a href="<?php echo e(url('admin/empleados')); ?>" class="small-box-footer">Más información <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e($inactivos); ?></h3>

                        <p>Empleados inactivos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-pause"></i>
                    </div>
                    <a href="<?php echo e(url('admin/empleados')); ?>" class="small-box-footer">Más información <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="row">

            <?php if($empleados): ?>
            <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <!-- Widget: user widget style 2 -->
                <div class="card card-widget widget-user-2">
                    <!-- Add the bg color to the header using any of the bg-* classes -->
                    <div class="widget-user-header bg-info">
                        <div class="widget-user-image">
                            <?php switch($empleado->empleado_genero):
                                case ("Masculino"): ?>
                                    <img class="img-circle elevation-2" src="<?php echo e(asset('public/img/man.png')); ?>" alt="User Avatar">
                                    <?php break; ?>
                                <?php case ("Femenino"): ?>
                                    <img class="img-circle elevation-2" src="<?php echo e(asset('public/img/woman.png')); ?>" alt="User Avatar">
                                    <?php break; ?>
                                <?php default: ?>
                                    <img class="img-circle elevation-2" src="<?php echo e(asset('public/img/user.png')); ?>" alt="User Avatar">
                            <?php endswitch; ?>

                        </div>
                        <!-- /.widget-user-image -->
                        <h3 class="widget-user-username"><?php echo e($empleado->empleado_nombre." ".$empleado->empleado_apellido); ?></h3>
                        <h5 class="widget-user-desc"><?php echo e($empleado->cargos->cargo_nombre); ?></h5>
                    </div>
                    <div class="card-footer p-0">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                                    Estado <span class="float-right badge <?php echo e($empleado->estado_turno ? "bg-success":"bg-warning"); ?>"><?php echo e($empleado->estado_turno ? "TRABAJANDO":"INACTIVO"); ?></span>
                                </a>
                            </li>


                        </ul>
                    </div>
                </div>
                <!-- /.widget-user -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        </div>


        <!-- /.row -->
    </div><!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\Proyectos\hestia\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>